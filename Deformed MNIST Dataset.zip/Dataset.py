import numpy as np

X_train_images = np.loadtxt('80000 deformed MNIST training images.txt') #(80000,784)
X_train_labels = np.loadtxt('80000 deformed MNIST training labels.txt') #(80000,11)


X_test_images = np.loadtxt('11000 deformed MNIST test images.txt') #(11000,784)
Y_test_labels = np.loadtxt('11000 deformed MNIST test labels.txt') #(11000,11)
